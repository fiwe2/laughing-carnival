import { beforeEach, describe, expect, test } from 'bun:test';
import { mcpAddCommand, mcpEndpoint } from '@marklayer/brand/links';
import type { DrawOp } from '@marklayer/types/ops';
import { getRoomId, resetRoomIdentity, setAnnotationId } from './room-id';
import {
  getShareUrl,
  isLikelyEmbedHostile,
  isShareableUrl,
  loadAnnotations,
  npxMcpCommand,
  parseShareRef,
  saveAnnotations,
  shareUrl,
  withShareRef,
} from './share';

describe('isShareableUrl', () => {
  test('X41 refuses every address the proxy refuses, not only loopback', () => {
    const hosts = ['10.0.0.1', '172.16.0.1', '192.168.1.1', '169.254.169.254', 'db.internal'];
    expect(hosts.filter((host) => isShareableUrl(`http://${host}`))).toEqual([]);
  });

  test('accepts an ordinary public page over either web protocol', () => {
    expect(isShareableUrl('https://example.com/docs')).toBe(true);
    expect(isShareableUrl('http://example.com')).toBe(true);
  });

  test('rejects protocols the share viewer cannot fetch', () => {
    // The viewer refetches the page server-side, so anything not addressable
    // over HTTP resolves to an empty frame.
    expect(isShareableUrl('file:///Users/me/page.html')).toBe(false);
    expect(isShareableUrl('chrome-extension://abc/options.html')).toBe(false);
    expect(isShareableUrl('about:blank')).toBe(false);
    expect(isShareableUrl('data:text/html,<p>hi')).toBe(false);
  });

  test('rejects loopback in every spelling', () => {
    for (const host of ['localhost', '0.0.0.0', '127.0.0.1', '127.1.2.3', '[::1]']) {
      expect(isShareableUrl(`http://${host}:3000/app`)).toBe(false);
    }
  });

  test('rejects the local-network suffixes a dev machine advertises itself under', () => {
    expect(isShareableUrl('http://app.localhost:5173')).toBe(false);
    expect(isShareableUrl('http://macbook.local/dashboard')).toBe(false);
  });

  test('rejects an unparseable string instead of throwing at the call site', () => {
    expect(isShareableUrl('not a url')).toBe(false);
    expect(isShareableUrl('')).toBe(false);
  });
});

describe('isLikelyEmbedHostile', () => {
  test('flags the known frame-busting hosts', () => {
    expect(isLikelyEmbedHostile('https://youtube.com/watch?v=x')).toBe(true);
    expect(isLikelyEmbedHostile('https://x.com/someone')).toBe(true);
  });

  test('matches through a www prefix, a subdomain, and mixed case', () => {
    expect(isLikelyEmbedHostile('https://www.instagram.com/p/1')).toBe(true);
    expect(isLikelyEmbedHostile('https://m.facebook.com/x')).toBe(true);
    expect(isLikelyEmbedHostile('https://WWW.TikTok.com/@a')).toBe(true);
  });

  test('does not flag a host that merely ends with the same letters', () => {
    // A suffix check without the dot would condemn every "…x.com" domain.
    expect(isLikelyEmbedHostile('https://notx.com/page')).toBe(false);
    expect(isLikelyEmbedHostile('https://myyoutube.com')).toBe(false);
    expect(isLikelyEmbedHostile('https://example.com')).toBe(false);
  });

  test('treats an unparseable url as embeddable rather than throwing', () => {
    expect(isLikelyEmbedHostile('nonsense')).toBe(false);
  });
});

describe('MCP connect commands', () => {
  // Both surfaces offer these verbatim for copy-paste; a dropped flag or a room
  // id that never reaches the string hands the user a command that just fails.
  test('point at the room’s own endpoint, so nothing has to be installed', () => {
    expect(mcpEndpoint({ roomId: 'room-42' })).toBe('https://marklayer.app/s/room-42/mcp');
    expect(mcpAddCommand({ roomId: 'room-42' })).toBe(
      'claude mcp add --transport http marklayer https://marklayer.app/s/room-42/mcp',
    );
  });

  test('keep the npx fallback intact, non-interactive flag and all', () => {
    expect(npxMcpCommand({ roomId: 'room-42' })).toBe('npx -y marklayer-mcp --room room-42');
  });

  test('a self-hosted origin reaches every command, npx via --api-base', () => {
    const origin = 'http://localhost:8787';
    expect(mcpEndpoint({ roomId: 'r', origin })).toBe('http://localhost:8787/s/r/mcp');
    expect(mcpAddCommand({ roomId: 'r', origin })).toContain('http://localhost:8787/s/r/mcp');
    expect(npxMcpCommand({ roomId: 'r', origin })).toBe(
      'npx -y marklayer-mcp --room r --api-base http://localhost:8787',
    );
  });
});

describe('room identity', () => {
  test('reuses one id across share surfaces so collaborators land on one canvas', () => {
    const first = getRoomId();
    expect(getRoomId()).toBe(first);
    expect(getShareUrl()).toBe(`https://marklayer.app/s/${first}?ref=ext`);
  });

  test('adopting an existing id repoints the share url at it', () => {
    setAnnotationId('adopted-id');
    expect(getRoomId()).toBe('adopted-id');
    expect(getShareUrl()).toBe('https://marklayer.app/s/adopted-id?ref=ext');
  });
});

describe('share attribution', () => {
  test('accepts only the surfaces we name', () => {
    // The value arrives from the address bar, so whatever is accepted here is a
    // stranger choosing a property value in our analytics.
    expect(parseShareRef('web')).toBe('web');
    expect(parseShareRef('ext')).toBe('ext');
    expect(parseShareRef('dash')).toBe('dash');
    expect(parseShareRef('WEB')).toBeNull();
    expect(parseShareRef('<script>')).toBeNull();
    expect(parseShareRef(null)).toBeNull();
  });

  test('keeps the params a share link already carries', () => {
    // A `readonly` dropped here is a view-only link handed out as editable.
    expect(withShareRef({ url: 'https://marklayer.app/s/abc?readonly=1', ref: 'web' })).toBe(
      'https://marklayer.app/s/abc?readonly=1&ref=web',
    );
    expect(withShareRef({ url: 'https://marklayer.app/p/xyz?page=2', ref: 'dash' })).toBe(
      'https://marklayer.app/p/xyz?page=2&ref=dash',
    );
  });

  test('replaces an existing ref rather than appending a second', () => {
    // Re-sharing a link that arrived from somewhere else credits the surface it
    // is leaving from now, not the one it came in on.
    expect(withShareRef({ url: 'https://marklayer.app/s/abc?ref=ext', ref: 'web' })).toBe(
      'https://marklayer.app/s/abc?ref=web',
    );
  });
});

describe('shareUrl', () => {
  test('routes a project to /p and a page to /s', () => {
    expect(shareUrl({ origin: 'https://marklayer.app', kind: 'project', id: 'xyz', ref: 'web' })).toBe(
      'https://marklayer.app/p/xyz?ref=web',
    );
    expect(shareUrl({ origin: 'https://marklayer.app', kind: 'page', id: 'abc', ref: 'dash' })).toBe(
      'https://marklayer.app/s/abc?ref=dash',
    );
  });

  // The viewer copies this string and the share popover displays it; a readonly
  // lost between them hands out a view-only link as editable.
  test('carries readonly through alongside the ref', () => {
    expect(shareUrl({ origin: 'https://marklayer.app', kind: 'page', id: 'abc', readonly: true, ref: 'web' })).toBe(
      'https://marklayer.app/s/abc?readonly=1&ref=web',
    );
  });
});

describe('saveAnnotations and loadAnnotations', () => {
  // Room identity is a module singleton: without a reset, whichever test last
  // called `setAnnotationId` leaks a joined room into every test after it.
  beforeEach(() => {
    resetRoomIdentity();
  });

  /**
   * Swaps `fetch`, and captures the logging the failure paths do so the run stays
   * readable. Typed as the call signature rather than `typeof fetch`: Bun's fetch
   * carries a `preconnect` property that a stub has no reason to implement.
   */
  type FetchImpl = (input: URL | RequestInfo, init?: RequestInit) => Promise<Response>;
  const withFetch = async (impl: FetchImpl, body: (logged: string[]) => Promise<void>) => {
    const originalFetch = globalThis.fetch;
    const originalError = console.error;
    const logged: string[] = [];
    const swap = (key: 'fetch', value: unknown) =>
      Object.defineProperty(globalThis, key, { value, configurable: true, writable: true });
    swap('fetch', impl);
    console.error = (...args: unknown[]) => logged.push(args.map(String).join(' '));
    try {
      await body(logged);
    } finally {
      swap('fetch', originalFetch);
      console.error = originalError;
    }
  };

  const op: DrawOp = { id: 'op1', color: '#000', lineWidth: 2, tool: 'text', text: 'x', x: 0, y: 0, fontSize: 14 };

  test('posts the ops to the room, with the page url stripped of its hash', async () => {
    // The hash carries our own viewer state; storing it would make the saved
    // url a different page from the one annotated.
    window.location.hash = '#ant=1440=abc';
    const id = getRoomId(); // a freshly created room — the join guard only blocks a joined one
    // Collected into an array, not a nullable local: assigning inside the callback
    // leaves the checker convinced it is still null at the assertions below.
    const calls: { url: string; init: RequestInit | undefined }[] = [];

    await withFetch(
      async (input, init) => {
        calls.push({ url: String(input), init });
        return new Response('{}', { status: 200 });
      },
      async () => {
        expect(await saveAnnotations([op])).toEqual({ ok: true });
      },
    );

    expect(calls[0]?.url).toBe(`https://marklayer.app/api/${id}`);
    expect(calls[0]?.init?.method).toBe('POST');
    const sent: unknown = JSON.parse(String(calls[0]?.init?.body));
    expect(sent).toMatchObject({ ops: [op], url: 'https://example.com/page', width: window.innerWidth });
    window.location.hash = '';
  });

  test('reports a failed save rather than pretending it worked', async () => {
    await withFetch(
      async () => new Response('nope', { status: 500 }),
      async (logged) => {
        expect(await saveAnnotations([op])).toEqual({ ok: false, reason: 'error' });
        expect(logged.join()).toContain('Error saving annotations');
      },
    );
  });

  // The bug this guards: a 403 came back as the same generic failure as a 500,
  // so an owner who set their link view-only was told it "may not work".
  test('separates a view-only refusal from a broken save, and does not log it', async () => {
    await withFetch(
      async () => new Response('{"error":"This link is view-only."}', { status: 403 }),
      async (logged) => {
        expect(await saveAnnotations([op])).toEqual({ ok: false, reason: 'view-only' });
        expect(logged).toEqual([]);
      },
    );
  });

  test('reports a save that never reached the network', async () => {
    await withFetch(
      async () => {
        throw new Error('offline');
      },
      async (logged) => {
        expect(await saveAnnotations([op])).toEqual({ ok: false, reason: 'error' });
        expect(logged.join()).toContain('Error saving annotations');
      },
    );
  });

  // POST /api/:id is a full replace server-side, so a joiner's snapshot would bin
  // everyone else's ops. The guard has to refuse before the request goes out.
  test('refuses to push a snapshot to a joined room, without touching the network', async () => {
    setAnnotationId('someone-elses-room');
    let fetchCalled = false;
    await withFetch(
      async () => {
        fetchCalled = true;
        return new Response('{}', { status: 200 });
      },
      async () => {
        expect(await saveAnnotations([op])).toEqual({ ok: false, reason: 'joined-room' });
      },
    );
    expect(fetchCalled).toBe(false);
  });

  // GET /api/:id answers `{ ops, url, width }`; only the array spelling used to load, so joining failed in production.
  test('loads the ops out of the API response object', async () => {
    await withFetch(
      async () => Response.json({ ops: [op], url: 'https://example.com/', width: 1280 }),
      async () => {
        expect(await loadAnnotations('room-1')).toEqual([op]);
      },
    );
  });

  test('returns null for a missing room, so a caller can tell it apart from an empty one', async () => {
    // An empty array is a real canvas with nothing on it; null is a failure.
    await withFetch(
      async () => new Response('not found', { status: 404 }),
      async (logged) => {
        expect(await loadAnnotations('gone')).toBeNull();
        expect(logged.join()).toContain('Error loading annotations');
      },
    );
  });

  test('returns null when the response is not the JSON it claims to be', async () => {
    await withFetch(
      async () => new Response('<html>error page</html>', { status: 200 }),
      async (logged) => {
        expect(await loadAnnotations('room-1')).toBeNull();
        expect(logged.join()).toContain('Error loading annotations');
      },
    );
  });
});
